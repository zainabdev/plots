import numpy as np
import pandas as pd
df = pd.read_csv('hungary_chickenpox_data.csv')
df.head()

df['year'] = pd.to_datetime(df['Date']).dt.strftime('%Y')
df.isnull().sum()
df1 = df.groupby('year').sum()
df1
import seaborn as sns
import matplotlib.pyplot as plt
sns.set_theme(style="whitegrid")
sns.set_color_codes("dark")
k = 0
f, axes = plt.subplots(5,2, figsize=(15,40))
for i in range(len(df1)//2):
    for j in range(2):
        year = df1.index[k]
        regions = list(df1.iloc[i].index)
        cases = list(df1.iloc[i].values)
    #     print(cases)
        sns.barplot(cases, regions, color="b", ax = axes[i,j])
        axes[i,j].set_title(f"The total Cases reported in the year" + ' ' + str(year))
        k = k + 1

